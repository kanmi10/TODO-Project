package com.test.todo.member;

import lombok.Data;

@Data
public class PlusRewardDTO {

	private String seq;
	private String mseq;
	private String regdate;
	private String pseq;	
	
	private int plusPoint;
	private String plusName;
	
}
