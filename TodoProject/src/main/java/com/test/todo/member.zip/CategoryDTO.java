package com.test.todo.member;

import lombok.Data;

/**
 * 
 * CategoryDTO 클래스입니다.
 * 카테고리 이름 getter, setter 
 * 
 * @author 김경현
 *
 */

@Data
public class CategoryDTO {
	
	private String name;

}
